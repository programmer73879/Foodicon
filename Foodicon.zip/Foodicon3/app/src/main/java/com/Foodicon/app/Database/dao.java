package com.Foodicon.app.Database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.Foodicon.app.Models.Cart;
import com.Foodicon.app.Models.product;

import java.util.List;

@Dao
public interface dao {
    @Insert
    void insert(Entity entity);

    @Update
    void update(Entity entity);

   @Delete
   void delete(Entity entity);

    @Query("SELECT * FROM cart WHERE id = :id")
    Entity getentity(String id);

    @Query("SELECT * FROM cart")
    List<Entity> getlist();

     @Query("DELETE FROM cart")
     void deleteall();

}
