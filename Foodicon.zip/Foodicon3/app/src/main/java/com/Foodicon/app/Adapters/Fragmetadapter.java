package com.Foodicon.app.Adapters;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.Foodicon.app.Fragments.AccountFragment;
import com.Foodicon.app.Fragments.CartFragment;
import com.Foodicon.app.Fragments.HomeFragment;
import com.Foodicon.app.Fragments.ProfileFragment;
import com.Foodicon.app.Models.Cart;

import org.jetbrains.annotations.NotNull;

public class Fragmetadapter extends FragmentStateAdapter {
    public Fragmetadapter(@NonNull @NotNull FragmentManager fragmentManager, @NonNull @NotNull Lifecycle lifecycle) {
        super(fragmentManager, lifecycle);
    }

    @NonNull
    @NotNull
    @Override
    public Fragment createFragment(int position) {
        switch (position){
            case 0:
                return new HomeFragment();
            case 1:
                return new CartFragment();
            case 2:
                return new ProfileFragment();
            case 3:
               return new AccountFragment();

        }
        return new HomeFragment();
    }

    @Override
    public int getItemCount() {
        return 4;
    }
}
