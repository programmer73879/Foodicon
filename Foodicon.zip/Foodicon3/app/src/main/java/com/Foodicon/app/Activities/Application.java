package com.Foodicon.app.Activities;

import android.content.SharedPreferences;
import android.util.Log;
import com.Foodicon.app.Models.product;
import java.util.ArrayList;
import java.util.HashMap;

public class Application  extends android.app.Application {
    static ArrayList<product> arrayList;
    int total;
 public   static   ArrayList<product> order;
public static HashMap<String,product> hashMap;
   private static Application ins;
    @Override
    public void onCreate() {
        super.onCreate();
        order = new ArrayList<>();
        arrayList = new ArrayList<>();
        hashMap = new HashMap<>();

    }
    public static Application getinstance(){
        if (ins==null) {
            ins = new Application();
            return ins;
        }
        return ins;
    }

    public ArrayList<product> getArrayList() {
        return arrayList;
    }
    public void addtocart(product product){
        total  =  (int) total+((int)product.getPrice()*product.getQty());
        hashMap.put(product.getId(),product);
        Log.d("size", "addtocart: "+hashMap.size());
    }
    public void removefromcart(product product){
        total  =  (int) total-((int)product.getPrice()*product.getQty());
        hashMap.put(product.getId(),product);
        Log.d("size", "addtocart: "+hashMap.size());
    }
    public void setArrayList(ArrayList<product> arrayList) {
        Application.arrayList = arrayList;
    }

}
