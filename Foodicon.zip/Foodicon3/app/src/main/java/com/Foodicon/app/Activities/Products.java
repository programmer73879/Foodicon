package com.Foodicon.app.Activities;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.Foodicon.app.Adapters.adapter;
import com.Foodicon.app.Adapters.prodadapter;
import com.Foodicon.app.Models.product;
import com.Foodicon.app.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.mapbox.mapboxsdk.log.LoggerDefinition;
import com.mcdev.quantitizerlibrary.HorizontalQuantitizer;
import com.mcdev.quantitizerlibrary.QuantitizerListener;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class Products extends AppCompatActivity {
    ImageView imageView;
    FirebaseDatabase firebaseDatabase;
    RecyclerView recyclerView;
    ArrayList<product> arrayList;
    Toolbar toolbar;
    prodadapter prodadapter;
    HorizontalQuantitizer horizontalQuantitizer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_productshow);
        firebaseDatabase  = FirebaseDatabase.getInstance();
        arrayList = new ArrayList<>();
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

//        Picasso.with(this).load(getIntent().getStringExtra("image")).into(imageView);
//        name.setText(getIntent().getStringExtra("name"));
//        tagline.setText(getIntent().getStringExtra("tagline"));
//        price.setText(getIntent().getStringExtra("price"));
//        horizontalQuantitizer.setMinusIconColor(R.color.mapbox_plugins_green);
//        horizontalQuantitizer.setPlusIconColor(R.color.mapbox_plugins_green);
//        horizontalQuantitizer.setMinusIconBackgroundColor(R.color.black);
//        horizontalQuantitizer.setPlusIconBackgroundColor(R.color.black);
        recyclerView = findViewById(R.id.rcitems);
        imageView  = findViewById(R.id.image);
        Toast.makeText(this, ""+getIntent().getStringExtra("id"), Toast.LENGTH_SHORT).show();
        Picasso.with(this)
                .load(getIntent().getStringExtra("link")).into(imageView);
        firebaseDatabase.getReference().child(getSharedPreferences("Restaurant",MODE_PRIVATE
        ).getString("resid",null)+"dets").child("Products").child(getIntent().getStringExtra("name")).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                arrayList.clear();
                for (DataSnapshot snapshot1:snapshot.getChildren()){
              product product = snapshot1.getValue(com.Foodicon.app.Models.product.class);
              product.setId(snapshot1.getKey());
              arrayList.add(product);
          }
          recyclerView.setLayoutManager(new LinearLayoutManager(Products.this));
          prodadapter prodadapter = new prodadapter(Products.this,arrayList);
          recyclerView.setAdapter(prodadapter);
            }

            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });
    }
}