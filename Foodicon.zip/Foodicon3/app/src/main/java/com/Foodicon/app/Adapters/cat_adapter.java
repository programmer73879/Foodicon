package com.Foodicon.app.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.Foodicon.app.Activities.MainActivity;
import com.Foodicon.app.Activities.Products;
import com.Foodicon.app.Models.Cateogry;
import com.Foodicon.app.R;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class cat_adapter extends RecyclerView.Adapter<cat_adapter.holder>{
    ArrayList<Cateogry> arrayList;
    Context context;

    public cat_adapter(ArrayList<Cateogry> arrayList, Context context) {
        this.arrayList = arrayList;
        this.context = context;
    }

    @NonNull
    @NotNull
    @Override
    public holder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
          View view = LayoutInflater.from(context).inflate(R.layout.category,parent,false);
          return new holder(view);
     }

    @Override
    public void onBindViewHolder(@NonNull @NotNull holder holder, int position) {
        Picasso
                .with(context)
                .load(arrayList.get(position).getUrl())
                .fit()
                // call .centerInside() or .centerCrop() to avoid a stretched image
                .into(holder.imageView);
         holder.name.setText(arrayList.get(position).getName());
         holder.imageView.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 Intent intent = new Intent(context,Products.class);
                 intent.putExtra("id",arrayList.get(position).getId());
                 intent.putExtra("link",arrayList.get(position).getUrl());
                 intent.putExtra("name",arrayList.get(position).getName());
                 ((MainActivity)context).startActivity(intent);
             }
         });
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }


    public static class holder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView name;
        public holder(@NonNull @NotNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.img);
            name = itemView.findViewById(R.id.name);
        }
    }
}
