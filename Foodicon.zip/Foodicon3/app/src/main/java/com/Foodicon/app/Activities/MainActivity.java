package com.Foodicon.app.Activities;


import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.Foodicon.app.Fragments.CartFragment;
import com.Foodicon.app.Fragments.HomeFragment;
import com.Foodicon.app.Fragments.ProfileFragment;
import com.Foodicon.app.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.database.FirebaseDatabase;
import com.google.gson.JsonArray;
import com.mapbox.api.geocoding.v5.models.CarmenFeature;
import com.mapbox.geojson.Point;
import com.mapbox.mapboxsdk.Mapbox;
import com.mapbox.mapboxsdk.camera.CameraPosition;
import com.mapbox.mapboxsdk.geometry.LatLng;
import com.mapbox.mapboxsdk.plugins.places.autocomplete.PlaceAutocomplete;
import com.mapbox.mapboxsdk.plugins.places.autocomplete.model.PlaceOptions;
import com.mapbox.mapboxsdk.plugins.places.picker.PlacePicker;
import com.mapbox.mapboxsdk.plugins.places.picker.model.PlacePickerOptions;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;

import java.util.ArrayDeque;
import java.util.Deque;

import timber.log.Timber;

public class MainActivity extends AppCompatActivity implements NavigationBarView.OnItemSelectedListener {
BottomNavigationView chipNavigationBar;
FirebaseDatabase firebaseDatabase;
FrameLayout frameLayout;
FloatingActionButton actionButton;
    private Deque<Integer> fragmentIds = new ArrayDeque<>(3);
    int itemId;
    ActivityResultLauncher<Intent> activityResultLauncher,resultLauncher;
    private HomeFragment homeFragment = new HomeFragment();
    private CartFragment favouriteFragment = new CartFragment();
    private ProfileFragment nearmeFragment = new ProfileFragment();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        activityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                CarmenFeature selectedCarmenFeature = PlaceAutocomplete.getPlace(result.getData());
                double lat  = ((Point)selectedCarmenFeature.geometry()).latitude();
                double lon  = ((Point)selectedCarmenFeature.geometry()).longitude();
                goToPickerActivity(lat,lon);
            }
        });
        resultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                Toast.makeText(MainActivity.this, ""+result.getData().toString(), Toast.LENGTH_SHORT).show();

            }
        });
        chipNavigationBar = findViewById(R.id.bottom);
        firebaseDatabase = FirebaseDatabase.getInstance();
        frameLayout = findViewById(R.id.container);
        Mapbox.getInstance(MainActivity.this, getString(R.string.access_token));
        fragmentIds.push(R.id.home);
        actionButton  = findViewById(R.id.fab);
        showTabWithoutAddingToBackStack(homeFragment);
        chipNavigationBar.setOnItemSelectedListener(this);
        actionButton.setOnClickListener(v -> {
            Intent intent = new PlaceAutocomplete.IntentBuilder()
                    .accessToken(Mapbox.getAccessToken() != null ? Mapbox.getAccessToken() : getString(R.string.access_token))
                    .placeOptions(PlaceOptions.builder()
                            .backgroundColor(Color.parseColor("#EEEEEE"))
                            .limit(10)
                            .statusbarColor(Color.BLACK)

                            .build(PlaceOptions.MODE_CARDS))
                    .build(MainActivity.this);
   activityResultLauncher.launch(intent);
        });
    }



    private void goToPickerActivity(double lat,double lon) {
      Intent intent  =
                new PlacePicker.IntentBuilder()
                        .accessToken(getString(R.string.access_token))
                        .placeOptions(PlacePickerOptions.builder()
                                .includeDeviceLocationButton(true)
                                .includeReverseGeocode(true)
                                .toolbarColor(Color.BLACK)
                                .statingCameraPosition(new CameraPosition.Builder()
                                        .target(new LatLng(lat, lon)).zoom(16).build())
                                .build())
                        .build(this);
      resultLauncher.launch(intent);
    }
    private Fragment getFragment(int fragmentId) {
        switch (fragmentId) {
            case R.id.home:
                return homeFragment;
            case R.id.cart:
                return favouriteFragment;
            case R.id.user:
                return nearmeFragment;
        }
        return homeFragment;
    }

    private void showTabWithoutAddingToBackStack(Fragment fragment) {
        getSupportFragmentManager().beginTransaction().replace(R.id.container, fragment, fragment.getClass().getSimpleName()).commit();
    }

    @Override
    public void onBackPressed() {
        if(fragmentIds.getLast() != R.id.home){
            fragmentIds.addLast(R.id.home);
        }
        fragmentIds.pop();
        chipNavigationBar.setSelectedItemId(fragmentIds.size()-1);
        if (!fragmentIds.isEmpty()) {
            showTabWithoutAddingToBackStack(getFragment(fragmentIds.peek()));
        } else {
            finish();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull @NotNull MenuItem item) {
        itemId=item.getItemId();
        if(fragmentIds.contains(itemId)){
            fragmentIds.remove(itemId);
        }
        chipNavigationBar.setSelectedItemId(fragmentIds.size()-1);
        fragmentIds.push(itemId);
        showTabWithoutAddingToBackStack(getFragment(itemId));
        return true;
    }
}