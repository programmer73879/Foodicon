package com.Foodicon.app.Activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.Foodicon.app.Models.User;
import com.Foodicon.app.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.jetbrains.annotations.NotNull;

public class Login extends AppCompatActivity implements View.OnClickListener{
TextView  tv_createac,forget;
Button btn_login;
FirebaseDatabase firebaseDatabase;
FirebaseAuth firebaseAuth;
TextInputLayout l_email,l_password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        initviews();
        animateviews();
        firebaseDatabase = FirebaseDatabase.getInstance();
        firebaseAuth = FirebaseAuth.getInstance();
    }

    @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB_MR1)
    private void animateviews() {
        int[][] states = new int[][] {
                new int[] {-android.R.attr.state_focused},
                new int[] {android.R.attr.state_focused}// unchecked
        };

        int[] colors = new int[] {
                getResources().getColor(R.color.stroke_state_unchecked),
                getResources().getColor(R.color.stroke_state_checked)
        };
        l_email.setTranslationY(300);
        l_password.setTranslationY(300);
        l_email.setAlpha(0);
        l_password.setAlpha(0);
        l_email.setBoxStrokeColorStateList(new ColorStateList(states,colors));
        l_password.setBoxStrokeColorStateList(new ColorStateList(states,colors));
        l_email.animate().translationY(0).alpha(1).setDuration(300).setStartDelay(400).start();
        l_password.animate().translationY(0).alpha(1).setDuration(400).setStartDelay(600).start();
    }

    private void initviews() {
        tv_createac = findViewById(R.id.create_ac);
        forget = findViewById(R.id.forget);
        btn_login = findViewById(R.id.btn_login);
        l_email = findViewById(R.id.email);
        l_password = findViewById(R.id.password);
        btn_login.setOnClickListener(this);
        tv_createac.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch(id){
            case R.id.create_ac:
                Log.d("tag", "onClick: ");
                startActivity(new Intent(Login.this,Registration.class));
                break;
            case R.id.forget:
                Log.d("debug", "onClick: "+"forget");
                break;
            case R.id.btn_login:
                login();
                break;
        }
    }

    private void login() {
        firebaseAuth.signInWithEmailAndPassword(l_email.getEditText().getText().toString(),l_password.getEditText().getText().toString()).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {
                   firebaseDatabase.getReference().child("user").child(authResult.getUser().getUid()).addValueEventListener(new ValueEventListener() {
                       @Override
                       public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                           User user = snapshot.getValue(User.class);
                           SharedPreferences.Editor editor = getSharedPreferences("User",MODE_PRIVATE).edit();
                           editor.putBoolean("login",true);
                           editor.putString("email",user.getEmail());
                           editor.putString("name",user.getName());
                           editor.commit();
                           startActivity(new Intent(Login.this,MainActivity.class));
                       }

                       @Override
                       public void onCancelled(@NonNull @NotNull DatabaseError error) {

                       }
                   });
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull @NotNull Exception e) {
                Toast.makeText(Login.this, ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}