package com.Foodicon.app.Models;

public class User {
    String name;
    String email;
    String password;
    String phone;
    String Address;
    String city;
    String lat;
    String lon;
    public User(){

    }
  public User(String email,String password,String username){
      this.email = email;
      this.password = password;
      this.name = username;
  }
    public User(String name, String email, String password, String phone, String address, String city, String lat, String lon) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.phone = phone;
        Address = address;
        this.city = city;
        this.lat = lat;
        this.lon = lon;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLon() {
        return lon;
    }

    public void setLon(String lon) {
        this.lon = lon;
    }
}
