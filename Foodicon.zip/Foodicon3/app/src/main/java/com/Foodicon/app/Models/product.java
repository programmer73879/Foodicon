package com.Foodicon.app.Models;

public class product {
    String name;
    String id;
    String image;
    double price;
    String tag;
    boolean veg;
    String type;
    int qty;
    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public product() {
    }


    public product(String name, String id, String image, double price, String tag, boolean veg, String type) {
        this.name = name;
        this.id = id;
        this.image = image;
        this.price = price;
        this.tag = tag;
        this.veg = veg;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public boolean isVeg() {
        return veg;
    }

    public void setVeg(boolean veg) {
        this.veg = veg;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}