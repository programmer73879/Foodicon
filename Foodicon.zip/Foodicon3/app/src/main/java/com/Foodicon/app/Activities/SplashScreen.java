package com.Foodicon.app.Activities;

import android.Manifest;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.Foodicon.app.R;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.tasks.CancellationToken;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.OnTokenCanceledListener;
import com.google.android.gms.tasks.Task;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import org.jetbrains.annotations.NotNull;
import java.io.IOException;
import java.util.List;


public class SplashScreen extends AppCompatActivity {
ImageView imageView;
TextView textview;
Handler handler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        imageView = findViewById(R.id.imagemain);
        textview = findViewById(R.id.textview);
        Animation animation = AnimationUtils.loadAnimation(this,R.anim.zoomin);
        imageView.setAnimation(animation);
        textview.setTranslationY(300);
        textview.setAlpha(0);
        textview.animate().translationY(0).alpha(1).setDuration(1100).setStartDelay(200).start();
        handler = new Handler(Looper.myLooper());
        LocationRequest locationRequest = LocationRequest.create();
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder()
                .addLocationRequest(locationRequest);
        SettingsClient client  = LocationServices.getSettingsClient(this);
        Task<LocationSettingsResponse> task = client.checkLocationSettings(builder.build());
        task.addOnSuccessListener(this, new OnSuccessListener<LocationSettingsResponse>() {
            @Override
            public void onSuccess(LocationSettingsResponse locationSettingsResponse) {

            }
        });

        task.addOnFailureListener(this, new OnFailureListener() {
            @Override
            public void onFailure(@NonNull @NotNull Exception e) {
                ResolvableApiException resolvableApiException = (ResolvableApiException) e;
                try {
                    resolvableApiException.startResolutionForResult(SplashScreen.this,0);
                } catch (IntentSender.SendIntentException sendIntentException) {
                    sendIntentException.printStackTrace();
                }
            }
        });
        Runnable runnable = () -> {
            if (getSharedPreferences("User",MODE_PRIVATE).getBoolean("login",false)){
            Intent i = new Intent(SplashScreen.this, MainActivity.class);
            startActivity(i);
            finish();}
            else {
                Intent i = new Intent(SplashScreen.this, Login.class);
                startActivity(i);
                finish();
            }
        };
        FusedLocationProviderClient fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(SplashScreen.this);
        CancellationToken cancellationToken = new CancellationToken() {
            @Override
            public boolean isCancellationRequested() {
                return false;
            }
            @NonNull
            @NotNull
            @Override
            public CancellationToken onCanceledRequested(@NonNull @NotNull OnTokenCanceledListener onTokenCanceledListener) {
                return null;
            }
        };
        fusedLocationProviderClient.getCurrentLocation(LocationRequest.PRIORITY_HIGH_ACCURACY,cancellationToken).addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
           List<Address> addresses  = null;
           while (addresses == null){
               try {
                   addresses = new Geocoder(SplashScreen.this).getFromLocation(location.getLatitude(),location.getLongitude(),1);
               } catch (IOException e) {
                   e.printStackTrace();
               }
           }
                Log.d("data", "onSuccess: "+addresses.get(0).toString());
                SharedPreferences.Editor editor = getSharedPreferences("User",MODE_PRIVATE).edit();
                editor.putString("city",addresses.get(0).getLocality());
                editor.putString("lat",String.valueOf(location.getLatitude()));
                editor.putString("lon",String.valueOf(location.getLongitude()));
                editor.commit();
                Log.d("iop", "onSuccess: "+location.getLongitude());
                handler.postDelayed(runnable,500);
            }
        });


        Dexter.withContext(this).withPermissions(Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION).withListener(new MultiplePermissionsListener() {
            @Override
            public void onPermissionsChecked(MultiplePermissionsReport multiplePermissionsReport) {

            }

            @Override
            public void onPermissionRationaleShouldBeShown(List<PermissionRequest> list, PermissionToken permissionToken) {

            }
        }).check();
    }
}