package com.Foodicon.app.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.Foodicon.app.R;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class slideradap extends RecyclerView.Adapter<slideradap.holder>{
    ArrayList<String> arrayList;
    Context context;


    public slideradap(ArrayList<String> arrayList, Context context) {
        this.arrayList = arrayList;
        this.context = context;
    }

    @NonNull
    @NotNull
    @Override
    public holder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.slider,parent,false);
        return new holder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull holder holder, int position) {
        Picasso
                .with(context)
                .load(arrayList.get(position))
                .fit()
                .into(holder.imageView);


    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public  static  class holder extends RecyclerView.ViewHolder {
        ImageView imageView ;
        public holder(@NonNull @NotNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.slider);
        }
    }
}
