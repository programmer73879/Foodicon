package com.Foodicon.app.Adapters;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.Foodicon.app.Activities.Add;
import com.Foodicon.app.Activities.Products;
import com.Foodicon.app.Database.Entity;
import com.Foodicon.app.Models.product;
import com.Foodicon.app.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.mcdev.quantitizerlibrary.HorizontalQuantitizer;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;
import java.util.List;


public class adapter extends RecyclerView.Adapter<adapter.holder> {
    List<product> arrayList;
    Context context;
    FirebaseAuth firebaseAuth;
    FirebaseDatabase database;
    int[] items;
    List<Entity> list;

    public adapter(List<product> arrayList, Context context) {
        this.arrayList = arrayList;
        this.context = context;
        firebaseAuth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        Log.d("adapter", "adapter: ");
    }

    @NonNull
    @NotNull
    @Override
    public holder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.cars,parent,false);
        return  new holder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull holder holder, int position) {
        product arrayList1  = arrayList.get(position);
//        for (Entity entity:list){
//            if (arrayList1.getId().equals(entity.getId())){
//                Log.d("tag", "onBindViewHolder: "+arrayList1.getId()+"   "+entity.getQty());
//                holder.horizontalQuantitizer.setValue(entity.getQty());
//            }
//        }

     holder.textView.setText(arrayList1.getName());
        Picasso
                .with(context)
                .load(arrayList1.getImage())
                .into(holder.imageView);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
      Intent intent = new Intent(context, Add.class);
      intent.putExtra("id",arrayList1.getId());
      intent.putExtra("image",arrayList1.getImage());
      intent.putExtra("name",arrayList1.getName());
      intent.putExtra("price",arrayList1.getPrice());
      intent.putExtra("tagline",arrayList1.getTag());
      intent.putExtra("veg",arrayList1.isVeg());
      context.startActivity(intent);
            }
        });
        holder.price.setText(String.valueOf(arrayList1.getPrice()));
//        holder.horizontalQuantitizer.setQuantitizerListener(new QuantitizerListener() {
//            @Override
//            public void onIncrease() {
//                Entity entity = Database.getInstance(context).getdao().getentity(arrayList1.getId());
//                if (entity!=null){
//                    int qty = entity.getQty();
//                    entity.setQty(++qty);
//                    int total = context.getSharedPreferences("cart",Context.MODE_PRIVATE).getInt("total",0);
//                    total = (int) (total+entity.getPrice());
//                    context.getSharedPreferences("cart",Context.MODE_PRIVATE).edit().putInt("total",total).commit();
//                    Database.getInstance(context).getdao().update(entity);
//                }
//                else {
//                    Entity entity1 = new Entity();
//                    entity1.setId(arrayList1.getId());
//                    entity1.setName(arrayList1.getName());
//                    entity1.setQty(1);
//                    int total = context.getSharedPreferences("cart",Context.MODE_PRIVATE).getInt("total",0);
//                    total = (int) (total+arrayList1.getPrice());
//                    context.getSharedPreferences("cart",Context.MODE_PRIVATE).edit().putInt("total",total).commit();
//                    entity1.setImage(arrayList1.getImage());
//                    entity1.setPrice(arrayList1.getPrice());
//                    entity1.setTag(arrayList1.getTag());
//                    entity1.setType(arrayList1.getType());
//                    Database.getInstance(context).getdao().insert(entity1);
//                }
//            }
//
//            @Override
//            public void onDecrease() {
//                int q = holder.horizontalQuantitizer.getValue();
//                if (++q==0){
//                    return;
//                }
//                Entity entity = Database.getInstance(context).getdao().getentity(arrayList1.getId());
//                if (entity!=null){
//                    int total = context.getSharedPreferences("cart",Context.MODE_PRIVATE).getInt("total",0);
//                    total = (int) (total-entity.getPrice());
//                    context.getSharedPreferences("cart",Context.MODE_PRIVATE).edit().putInt("total",total).commit();
//                    int qty = entity.getQty();
//                    entity.setQty(--qty);
//                    Database.getInstance(context).getdao().update(entity);
//                if (qty==0){
//                    Database.getInstance(context).getdao().delete(entity);
//                }
//                }
//            }
//        });

    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }


    public class holder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView textView;
        TextView price;
        HorizontalQuantitizer horizontalQuantitizer;
        ImageButton minus,add;
        TextView qty;
        public holder(@NonNull @NotNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.image);
            textView  = itemView.findViewById(R.id.name);
            price = itemView.findViewById(R.id.price);
        }
    }
}
