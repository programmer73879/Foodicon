package com.Foodicon.app.Activities;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.Foodicon.app.Models.User;
import com.Foodicon.app.R;
import com.airbnb.lottie.LottieAnimationView;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import org.jetbrains.annotations.NotNull;

public class Registration extends AppCompatActivity implements View.OnClickListener{
    TextInputEditText etusername,etphone,etpassword;
TextInputLayout  l_phone,l_password,l_username;
Button btn_register;
FirebaseAuth firebaseAuth;
FirebaseDatabase firebaseDatabase;
LottieAnimationView loadingAnimation;
String email,password,phone;
    @Override
    protected void onCreate(Bundle  savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        initviews();
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();
        animateEditText();

    }

    private void animateEditText() {
        int[][] states = new int[][] {
                new int[] {-android.R.attr.state_focused},
                new int[] {android.R.attr.state_focused}// unchecked
        };

        int[] colors = new int[] {
                getResources().getColor(R.color.stroke_state_unchecked),
                getResources().getColor(R.color.stroke_state_checked)
        };
        l_username.setTranslationY(300);
        l_password.setTranslationY(300);
        l_phone.setTranslationY(300);
        l_username.setAlpha(0);
        l_password.setAlpha(0);
        l_phone.setAlpha(0);
        l_username.setBoxStrokeColorStateList(new ColorStateList(states,colors));
        l_password.setBoxStrokeColorStateList(new ColorStateList(states,colors));
        l_phone.setBoxStrokeColorStateList(new ColorStateList(states,colors));
        l_phone.animate().translationY(0).alpha(1).setDuration(600).setStartDelay(400).start();
        l_username.animate().translationY(0).alpha(1).setDuration(700).setStartDelay(600).start();
        l_password.animate().translationY(0).alpha(1).setDuration(800).setStartDelay(800).start();
    }

    private void initviews() {
        l_phone = findViewById(R.id.l_email);
        l_username = findViewById(R.id.l_username);
        l_password = findViewById(R.id.l_password);
        etusername = findViewById(R.id.r_username);
        etphone = findViewById(R.id.r_email);
        etpassword = findViewById(R.id.r_password);
        btn_register = findViewById(R.id.btn_register);
        loadingAnimation = findViewById(R.id.r_lottie);
//        loadingAnimation.setAnimation(R.raw.dark);
//        loadingAnimation.setVisibility(View.VISIBLE);
//        loadingAnimation.playAnimation();
        btn_register.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.login_text:
                startActivity(new Intent(Registration.this,MainActivity.class));
                break;
            case R.id.btn_register:
                register();
        }
    }
    public void register(){
        firebaseAuth.createUserWithEmailAndPassword(l_phone.getEditText().getText().toString(),l_password.getEditText().getText().toString()).addOnSuccessListener(
                authResult -> {
                    User user = new User(l_phone.getEditText().getText().toString(),l_password.getEditText().getText().toString(),l_username.getEditText().getText().toString());
                    firebaseDatabase.getReference().child("user").child(authResult.getUser().getUid()).setValue(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            Toast.makeText(Registration.this, "Registration sucessfull", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
        ).addOnFailureListener(e -> Toast.makeText(Registration.this, ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show());
    }
}