package com.Foodicon.app.Models;

import java.util.ArrayList;

public class Cart {
    ArrayList<product> arrayList;
    int total;

    public Cart(ArrayList<product> arrayList, int total) {
        this.arrayList = arrayList;
        this.total = total;
    }
    public ArrayList<product> getArrayList() {
        return arrayList;
    }

    public void setArrayList(ArrayList<product> arrayList) {
        this.arrayList = arrayList;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }
}
