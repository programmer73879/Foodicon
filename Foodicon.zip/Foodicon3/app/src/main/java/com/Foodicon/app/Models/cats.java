package com.Foodicon.app.Models;

import java.util.ArrayList;

public class cats {
    String name;
   String url;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImg() {
        return url;
    }

    public void setImg(String img) {
        this.url = img;
    }

    public cats(String name, String img) {
        this.name = name;
        this.url = img;
    }

    public  cats(){

 }
}
