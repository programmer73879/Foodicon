package com.Foodicon.app.Activities;

import static com.mapbox.core.constants.Constants.PRECISION_6;
import static com.mapbox.mapboxsdk.style.layers.PropertyFactory.lineColor;
import static com.mapbox.mapboxsdk.style.layers.PropertyFactory.lineDasharray;
import static com.mapbox.mapboxsdk.style.layers.PropertyFactory.lineTranslate;
import static com.mapbox.mapboxsdk.style.layers.PropertyFactory.lineWidth;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import com.Foodicon.app.R;
import com.mapbox.api.directions.v5.DirectionsCriteria;
import com.mapbox.api.directions.v5.MapboxDirections;
import com.mapbox.api.directions.v5.models.DirectionsResponse;
import com.mapbox.api.directions.v5.models.DirectionsRoute;
import com.mapbox.geojson.Feature;
import com.mapbox.geojson.FeatureCollection;
import com.mapbox.geojson.LineString;
import com.mapbox.geojson.Point;
import com.mapbox.mapboxsdk.Mapbox;
import com.mapbox.mapboxsdk.camera.CameraPosition;
import com.mapbox.mapboxsdk.camera.CameraUpdate;
import com.mapbox.mapboxsdk.camera.CameraUpdateFactory;
import com.mapbox.mapboxsdk.geometry.LatLng;
import com.mapbox.mapboxsdk.maps.MapView;
import com.mapbox.mapboxsdk.maps.MapboxMap;
import com.mapbox.mapboxsdk.maps.OnMapReadyCallback;
import com.mapbox.mapboxsdk.maps.Style;
import com.mapbox.mapboxsdk.plugins.annotation.Symbol;
import com.mapbox.mapboxsdk.plugins.annotation.SymbolManager;
import com.mapbox.mapboxsdk.plugins.annotation.SymbolOptions;
import com.mapbox.mapboxsdk.style.layers.LineLayer;
import com.mapbox.mapboxsdk.style.layers.PropertyFactory;
import com.mapbox.mapboxsdk.style.layers.SymbolLayer;
import com.mapbox.mapboxsdk.style.sources.GeoJsonSource;
import com.mapbox.mapboxsdk.style.sources.Source;
import com.mapbox.mapboxsdk.utils.BitmapUtils;

import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ordertrack extends AppCompatActivity implements OnMapReadyCallback {
    MapView mapbox;
    private LatLng currentPosition ;
    MapboxMap mapboxmap;
    private static final String DIRECTIONS_LAYER_ID = "DIRECTIONS_LAYER_ID";
    private static final String LAYER_BELOW_ID = "road-label-small";
    private static final String SOURCE_ID = "SOURCE_ID";

    GeoJsonSource geoJsonSource,geoJsonSource1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Mapbox.getInstance(this, getString(R.string.access_token));
        setContentView(R.layout.ordertrack);
        mapbox = findViewById(R.id.map);
        mapbox.onCreate(savedInstanceState);
        mapbox.getMapAsync(this);
      currentPosition  = new LatLng(Double.valueOf(getSharedPreferences("Restaurant",MODE_PRIVATE).getFloat("lat",0)),Double.valueOf(getSharedPreferences("Restaurant",MODE_PRIVATE).getFloat("long",0))
 );

    }

    @Override
    protected void onStart() {
        super.onStart();
        mapbox.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mapbox.onResume();
    }

    @Override
    public void onMapReady(@NonNull final MapboxMap mapboxMap) {
        this.mapboxmap = mapboxMap;
        geoJsonSource = new GeoJsonSource("source-id",
                Feature.fromGeometry(Point.fromLngLat(currentPosition.getLongitude(),
                        currentPosition.getLatitude())));

geoJsonSource1 = new GeoJsonSource("source",Feature.fromGeometry(Point.fromLngLat(Double.valueOf(getSharedPreferences("User",MODE_PRIVATE).getString("lon","2")), Double.valueOf(getSharedPreferences("User",MODE_PRIVATE).getString("lat","2")))));
        mapboxMap.setStyle(Style.MAPBOX_STREETS, new Style.OnStyleLoaded() {
            @Override
            public void onStyleLoaded(@NonNull Style style) {
//                SymbolManager symbolManager = new SymbolManager(mapbox, mapboxMap, style);
                style.addImage("hotel",
                        BitmapUtils.getBitmapFromDrawable(ResourcesCompat.getDrawable(getResources(),R.drawable.cutlery,null)));// Set non-data-driven properties.
//                symbolManager.setIconAllowOverlap(true);
//                symbolManager.setTextAllowOverlap(true);
//                style.addImage("user",BitmapUtils.getBitmapFromDrawable(ResourcesCompat.getDrawable(getResources(),R.drawable.mapbox_marker_icon_default,null)));
//// Create a symbol at the specified location.
//                SymbolOptions symbolOptions = new SymbolOptions()
//                        .withLatLng(new LatLng(currentPosition.getLatitude(), currentPosition.getLongitude()))
//                        .withIconImage("hotel");
//                SymbolOptions symbolOptions1 = new SymbolOptions()
//                        .withLatLng(new LatLng(currentPosition.getLatitude(),currentPosition.getLongitude()))
//                        .withIconImage("user");
//
//
//
//// Use the manager to draw the symbol.
//                Symbol symbol = symbolManager.create(symbolOptions);
//                 Symbol symbol1 = symbolManager.create(symbolOptions1);
//                 Runnable runnable  = new Runnable() {
//                     @Override
//                     public void run() {
//                   runOnUiThread(new Runnable() {
//                       @Override
//                       public void run() {
//                           symbol1.setLatLng(new LatLng(67.90,78.0));
//                       }
//                   });
//                     }
//                 };
//                Handler handler = new Handler();
                style.addSource(geoJsonSource);
                style.addSource(geoJsonSource1);
//                handler.postDelayed(runnable,3000);
                style.addImage("user",
                        BitmapUtils.getBitmapFromDrawable(ResourcesCompat.getDrawable(getResources(),R.drawable.mapbox_marker_icon_default,null)));
style.addLayer(new SymbolLayer("layer-id","source-id").withProperties(
        PropertyFactory.iconImage("hotel"),
        PropertyFactory.iconIgnorePlacement(true),
        PropertyFactory.iconAllowOverlap(true)
));

style.addLayer(new SymbolLayer("layer","source")
.withProperties(
        PropertyFactory.iconImage("user"),
        PropertyFactory.iconAllowOverlap(true),
        PropertyFactory.iconIgnorePlacement(true)
));
                initDottedLineSourceAndLayer(style);



            }

        });
    }
    private void initDottedLineSourceAndLayer(@NonNull Style loadedMapStyle) {
        loadedMapStyle.addSource(new GeoJsonSource(SOURCE_ID));
        loadedMapStyle.addLayerBelow(
                new LineLayer(
                        DIRECTIONS_LAYER_ID, SOURCE_ID).withProperties(
                        lineWidth(4.5f),
                        lineColor(Color.BLACK),
                        lineTranslate(new Float[] {0f, 4f}),
                        lineDasharray(new Float[] {1.2f, 1.2f})
                ), LAYER_BELOW_ID);
        getRoute(Point.fromLngLat(currentPosition.getLongitude(),currentPosition.getLatitude()));
    }
    private void getRoute(Point destination) {
        MapboxDirections client = MapboxDirections.builder()
                .origin(Point.fromLngLat( 72.998199,21.705723))
                .destination(destination)
                .overview(DirectionsCriteria.OVERVIEW_FULL)
                .profile(DirectionsCriteria.PROFILE_WALKING)
                .accessToken(getString(R.string.access_token))
                .build();
        CameraPosition position = new CameraPosition.Builder()
                .target(new LatLng(destination.latitude(), destination.longitude()))
                .zoom(12)
                .tilt(20)
                .build();
        mapboxmap.animateCamera(CameraUpdateFactory.newCameraPosition(position),2000);
        client.enqueueCall(new Callback<DirectionsResponse>() {
            @Override
            public void onResponse(Call<DirectionsResponse> call, Response<DirectionsResponse> response) {
                if (response.body() == null) {
                    return;
                } else if (response.body().routes().size() < 1) {
                    return;
                }
                drawNavigationPolylineRoute(response.body().routes().get(0));
            }

            @Override
            public void onFailure(Call<DirectionsResponse> call, Throwable throwable) {
                if (!throwable.getMessage().equals("Coordinate is invalid: 0,0")) {
                    Toast.makeText(ordertrack.this,
                            "Error: " + throwable.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    private void drawNavigationPolylineRoute(final DirectionsRoute route) {
        if (mapboxmap != null) {
            mapboxmap.getStyle(new Style.OnStyleLoaded() {
                @Override
                public void onStyleLoaded(@NonNull Style style) {


                    List<Feature> directionsRouteFeatureList = new ArrayList<>();
                    LineString lineString = LineString.fromPolyline(route.geometry(), PRECISION_6);
                    List<Point> coordinates = lineString.coordinates();
                    for (int i = 0; i < coordinates.size(); i++) {
                        directionsRouteFeatureList.add(Feature.fromGeometry(LineString.fromLngLats(coordinates)));
                    }
                    FeatureCollection dashedLineDirectionsFeatureCollection = FeatureCollection.fromFeatures(directionsRouteFeatureList);
                    GeoJsonSource source = style.getSourceAs(SOURCE_ID);
                    if (source != null) {
                        source.setGeoJson(dashedLineDirectionsFeatureCollection);
                    }
                }
            });
        }
    }

}
