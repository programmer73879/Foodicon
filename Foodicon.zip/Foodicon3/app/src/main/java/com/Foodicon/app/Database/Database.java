package com.Foodicon.app.Database;

import android.content.Context;
import android.provider.ContactsContract;

import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

@androidx.room.Database(entities = {Entity.class},version = 1,exportSchema = false)
public abstract class Database extends RoomDatabase {
    private  static Database database;
    private static String dbname  = "Cart";
    public synchronized static Database getInstance(Context context){
        if (database==null){
            database = Room.databaseBuilder(context.getApplicationContext(),Database.class,dbname)
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return database;
    }
    public abstract dao getdao();
}
