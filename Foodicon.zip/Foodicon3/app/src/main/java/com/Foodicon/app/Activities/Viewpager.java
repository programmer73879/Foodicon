package com.Foodicon.app.Activities;

import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.viewpager2.widget.ViewPager2;
import com.Foodicon.app.R;

import org.jetbrains.annotations.NotNull;

public class Viewpager implements ViewPager2.PageTransformer {
    @Override
    public void transformPage(@NonNull @NotNull View page, float position) {
        Log.d("rahim", "transformPage: "+page.getId());
            TextView textView = (TextView) page;
            textView.setPivotX(33.7f);
            textView.setPivotY(89.7f);
    }
}
