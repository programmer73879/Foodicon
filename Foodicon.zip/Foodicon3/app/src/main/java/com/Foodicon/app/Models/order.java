package com.Foodicon.app.Models;

import com.Foodicon.app.Database.Entity;

import java.util.List;

public class order {
    String ordertime;
    String orderid;
    List<Entity> arrayList;
    String name;
    String orderdate;
    String phn;
    int total;
    String instructs;
    String Address;
    String status;
    String lat,lon;

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }
    public order(){

    }

    public order(String ordertime, String orderid, List<Entity> arrayList, String name, String orderdate, String phn, String instructs, String address, String status, String lat, String lon, int total) {
        this.ordertime = ordertime;
        this.orderid = orderid;
        this.arrayList = arrayList;
        this.name = name;
        this.orderdate = orderdate;
        this.phn = phn;
        this.instructs = instructs;
        Address = address;
        this.status = status;
        this.lat = lat;
        this.lon = lon;
        this.total = total;
    }

    public String getOrderid() {
        return orderid;
    }

    public void setOrderid(String orderid) {
        this.orderid = orderid;
    }

    public String getOrderdate() {
        return orderdate;
    }

    public void setOrderdate(String orderdate) {
        this.orderdate = orderdate;
    }

    public String getInstructs() {
        return instructs;
    }

    public void setInstructs(String instructs) {
        this.instructs = instructs;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getOrdertime() {
        return ordertime;
    }

    public void setOrdertime(String ordertime) {
        this.ordertime = ordertime;
    }

    public List<Entity> getArrayList() {
        return arrayList;
    }

    public void setArrayList(List<Entity> arrayList) {
        this.arrayList = arrayList;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhn() {
        return phn;
    }

    public void setPhn(String phn) {
        this.phn = phn;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLon() {
        return lon;
    }

    public void setLon(String lon) {
        this.lon = lon;
    }
}
