package com.Foodicon.app.Adapters;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.Foodicon.app.Database.Database;
import com.Foodicon.app.Database.Entity;
import com.Foodicon.app.R;
import com.bumptech.glide.Glide;
import com.google.firebase.database.FirebaseDatabase;
import com.mcdev.quantitizerlibrary.AnimationStyle;
import com.mcdev.quantitizerlibrary.HorizontalQuantitizer;
import com.mcdev.quantitizerlibrary.QuantitizerListener;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class basketAdapter extends RecyclerView.Adapter<basketAdapter.holder> {
    List<com.Foodicon.app.Database.Entity> arrayList;
    Context context;

   FirebaseDatabase database;

    public basketAdapter(List<Entity> arrayList, Context context) {
        this.arrayList = arrayList;
        this.context = context;
        database = FirebaseDatabase.getInstance();
    }

    @Override
    public @NotNull holder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.cardcart,parent,false);
        return new holder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull basketAdapter.holder holder, int position) {
         com.Foodicon.app.Database.Entity pricedata = arrayList.get(position);
        holder.prod_name.setText(pricedata.getName());

        holder.price.setText(String.valueOf(pricedata.getPrice()));
        holder.add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Entity entity = Database.getInstance(context).getdao().getentity(pricedata.getId());
                int qty = entity.getQty();
                qty++;
                int total = context.getSharedPreferences("Cart",Context.MODE_PRIVATE).getInt("total",0);
                SharedPreferences.Editor sharedPreferences = context.getSharedPreferences("Cart",Context.MODE_PRIVATE).edit();
                total = (int) (total+entity.getPrice());
                sharedPreferences.putInt("total",total);
                sharedPreferences.commit();
                holder.qty.setText(String.valueOf(qty));
                entity.setQty(qty);
                Database.getInstance(context).getdao().update(entity);

            }
        });
        holder.minus.setOnClickListener(v -> {
            if (Integer.valueOf(holder.qty.getText().toString().trim())==0){
                return;
            }
            Entity entity = Database.getInstance(context).getdao().getentity(pricedata.getId());
            int qty = entity.getQty();
            int total = context.getSharedPreferences("Cart",Context.MODE_PRIVATE).getInt("total",0);
            SharedPreferences.Editor sharedPreferences = context.getSharedPreferences("Cart",Context.MODE_PRIVATE).edit();
            total = (int) (total-entity.getPrice());
            sharedPreferences.putInt("total",total);
            sharedPreferences.commit();
            qty--;
            holder.qty.setText(String.valueOf(qty));
            if (Integer.valueOf(holder.qty.getText().toString().trim())==0){
                basketAdapter.this.notifyDataSetChanged();
                arrayList.remove(position);
                Intent intent = new Intent("empty cart");
                context.sendBroadcast(intent);
                basketAdapter.this.notifyDataSetChanged();
                Database.getInstance(context).getdao().delete(entity);
                return;
            }
            entity.setQty(qty);

            Database.getInstance(context).getdao().update(entity);
        });

//        holder.Add.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//            }
//        });
//        holder.minus.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//
//            }
//        });
//        holder.horizontalQuantitizer.setValue(pricedata.getQty());
//        holder.finalttl.setText(String.valueOf(pricedata.getQty()*pricedata.getPrice()));
//        holder.horizontalQuantitizer.setQuantitizerListener(new QuantitizerListener() {
//            @Override
//            public void onIncrease() {
//                Entity entity = Database.getInstance(context).getdao().getentity(pricedata.getId());
//                if (entity!=null){
//                    int qty = entity.getQty();
//                    entity.setQty(++qty);
//                    int total = context.getSharedPreferences("cart",Context.MODE_PRIVATE).getInt("total",0);
//                    total = (int) (total+entity.getPrice());
//                    context.getSharedPreferences("cart",Context.MODE_PRIVATE).edit().putInt("total",total).commit();
//                    Database.getInstance(context).getdao().update(entity);
//                    holder.horizontalQuantitizer.setValue(qty);
//                    holder.finalttl.setText(String.valueOf(qty*pricedata.getPrice()));
//                }
//            }
//
//            @Override
//            public void onDecrease() {
//                Entity entity = Database.getInstance(context).getdao().getentity(pricedata.getId());
//                if (entity!=null&&entity.getQty()!=0){
//                    int qty = entity.getQty();
//                    entity.setQty(--qty);
//                    int total = context.getSharedPreferences("cart",Context.MODE_PRIVATE).getInt("total",0);
//                    total = (int) (total-entity.getPrice());
//                    context.getSharedPreferences("cart",Context.MODE_PRIVATE).edit().putInt("total",total).commit();
//                    Database.getInstance(context).getdao().update(entity);
//                    holder.horizontalQuantitizer.setValue(qty);
//                    holder.finalttl.setText(String.valueOf(qty*pricedata.getPrice()));
//                    if (qty==0){
//                        Database.getInstance(context).getdao().delete(entity);
//                        arrayList.remove(position);
//                    }
//                }
//
//            }
//        });
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public  class  holder extends RecyclerView.ViewHolder {
        TextView price,prod_name;
        ImageView add,minus;
        TextView qty;
        public holder(@NonNull @NotNull View itemView) {
            super(itemView);
//            horizontalQuantitizer = itemView.findViewById(R.id.hq);
//            horizontalQuantitizer.setTextAnimationStyle(AnimationStyle.FALL_IN);
//            horizontalQuantitizer.setPlusIconColor(R.color.white);
//            horizontalQuantitizer.setMinValue(0);
//            horizontalQuantitizer.setPlusIconBackgroundColor(R.color.white);
//            horizontalQuantitizer.setMinusIconBackgroundColor(R.color.white);
//            horizontalQuantitizer.setMinusIconColor(R.color.white);
//            horizontalQuantitizer.setValueBackgroundColor(R.color.Bottom_navigation_color);
            prod_name = itemView.findViewById(R.id.name);
       price = itemView.findViewById(R.id.price);
//            finalttl = itemView.findViewById(R.id.totalfinal);
            add = itemView.findViewById(R.id.add);
            minus  = itemView.findViewById(R.id.minus);
            qty = itemView.findViewById(R.id.qty);

        }
    }


}
