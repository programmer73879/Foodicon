package com.Foodicon.app.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.Foodicon.app.Activities.Add;
import com.Foodicon.app.Models.product;
import com.Foodicon.app.R;
import com.squareup.picasso.Picasso;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class prodadapter  extends RecyclerView.Adapter<prodadapter.holder>{
    Context context;
    ArrayList<product> arrayList;

    public prodadapter(Context context, ArrayList<product> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    @NonNull
    @NotNull
    @Override
    public holder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.demolayout,parent,false);
        return new holder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull prodadapter.holder holder, int position) {
        product arrayList1 = arrayList.get(position);
        Picasso.with(context
        ).load(arrayList.get(position).getImage()).into(holder.imageView);
        holder.name.setText(arrayList.get(position).getName());
        holder.price.setText(String.valueOf(arrayList.get(position).getPrice()));
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Add.class);
                intent.putExtra("id",arrayList1.getId());
                intent.putExtra("image",arrayList1.getImage());
                intent.putExtra("name",arrayList1.getName());
                intent.putExtra("price",arrayList1.getPrice());
                intent.putExtra("tagline",arrayList1.getTag());
                intent.putExtra("veg",arrayList1.isVeg());
                context.startActivity(intent);
            }
        });
    }
    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public static  class holder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView name,price;
        public holder(@NonNull @NotNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.image);
            name = itemView.findViewById(R.id.name);
            price = itemView.findViewById(R.id.price);
        }
    }
}
