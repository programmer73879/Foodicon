package com.Foodicon.app.Models;

public class Restaurant {
    String name;
    String Address;
    double lat;
    String id;
    String fooddescription;
    double Long;
    String storestatus;
    String image;
    String ownername;
    String Phone;
    String email;
    String city;

    public String getFooddescription() {
        return fooddescription;
    }

    public void setFooddescription(String fooddescription) {
        this.fooddescription = fooddescription;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Restaurant(){
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStorestatus() {
        return storestatus;
    }

    public void setStorestatus(String storestatus) {
        this.storestatus = storestatus;
    }

    public Restaurant(String name, String address, double lat, double aLong, String ownername, String phone, String email, String city, String img, String id, String store) {
        this.name = name;
        Address = address;
        this.storestatus = store;
        this.lat = lat;
        this.image = img;
        Long = aLong;
        this.id = id;
        this.ownername = ownername;
        Phone = phone;
        this.email = email;
        this.city = city;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLong() {
        return Long;
    }

    public void setLong(double aLong) {
        Long = aLong;
    }

    public String getOwnername() {
        return ownername;
    }

    public void setOwnername(String ownername) {
        this.ownername = ownername;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
}
