package com.Foodicon.app.Fragments;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.Foodicon.app.Adapters.basketAdapter;
import com.Foodicon.app.Database.Database;
import com.Foodicon.app.Database.Entity;
import com.Foodicon.app.Models.order;
import com.Foodicon.app.R;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import org.jetbrains.annotations.NotNull;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

public class CartFragment extends Fragment {
private static CartFragment cartFragment=null;
FirebaseDatabase firebaseDatabase;
    RecyclerView cart;
    FirebaseAuth firebaseAuth;
    ImageView imageView;
    TextView textView;
    TextView del,delcharge,total,totaltext;
Button button;
View view;
BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
    @Override
    public void onReceive(Context context, Intent intent) {
     if (intent.getAction() == "empty cart"){
         cart.setVisibility(View.GONE);
         button.setVisibility(View.GONE);
         del.setVisibility(View.GONE);
         delcharge.setVisibility(View.GONE);
         total.setVisibility(View.GONE);
         totaltext.setVisibility(View.GONE);
         Log.d("br", "onReceive: ");
         imageView.setVisibility(View.VISIBLE);
         textView.setVisibility(View.VISIBLE);     }
    }
};

    @Override
    public void onCreate(@Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();
    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        cart = view.findViewById(R.id.basket_rc);
        del = view.findViewById(R.id.charge);
        delcharge = view.findViewById(R.id.del_Cahrge);
        total = view.findViewById(R.id.total);
        totaltext = view.findViewById(R.id.totaltext);
    button = view.findViewById(R.id.btn);
    imageView = view.findViewById(R.id.imgg);
    textView = view.findViewById(R.id.cart);
        total.setText(String.valueOf(getContext().getSharedPreferences("cart",Context.MODE_PRIVATE).getInt("total",0)));
        SharedPreferences.OnSharedPreferenceChangeListener sharedPreferenceChangeListener = new SharedPreferences.OnSharedPreferenceChangeListener() {
       @Override
       public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
           total.setText(String.valueOf(sharedPreferences.getInt("total",0)));
       }
   };
   getContext().getSharedPreferences("Cart",Context.MODE_PRIVATE).registerOnSharedPreferenceChangeListener(sharedPreferenceChangeListener);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        if (view==null){
            view =  inflater.inflate(R.layout.fragment_cart, container, false);
        }
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("empty cart");
        getContext().registerReceiver(broadcastReceiver,intentFilter);
        button.setOnClickListener(view -> {
            String id = firebaseDatabase.getReference().push().getKey();
            int uid  = new Random().nextInt(100000);
            List<Entity> list  = Database.getInstance(getContext()).getdao().getlist();
            if (list.size()==0){
                return;
            }
            getContext().getSharedPreferences("cart",Context.MODE_PRIVATE).registerOnSharedPreferenceChangeListener(new SharedPreferences.OnSharedPreferenceChangeListener() {
                @Override
                public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {

                }
            });
            SimpleDateFormat currentdate  = new SimpleDateFormat("dd/MM/yyyy ");
            SimpleDateFormat currentime  = new SimpleDateFormat("HH:mm a");
            Date date = new Date();
            int total = getContext().getSharedPreferences("Cart",Context.MODE_PRIVATE).getInt("total",0);
            order order = new order(currentime.format(date),String.valueOf(uid),list,getContext().getSharedPreferences("User",Context.MODE_PRIVATE).getString("name",null),currentdate.format(date)
           ,getContext().getSharedPreferences("User",Context.MODE_PRIVATE).getString("phn",null),"l",getContext().getSharedPreferences("User",Context.MODE_PRIVATE).getString("Address",null),"PREPARING",getContext().getSharedPreferences("User",Context.MODE_PRIVATE
            ).getString("lat",null),getContext().getSharedPreferences("User",Context.MODE_PRIVATE).getString("lon",null),total);
            firebaseDatabase.getReference().child("Restaurants").child(getContext().getSharedPreferences("Restaurant",Context.MODE_PRIVATE).getString("resid",null)+"dets").child("orders").child(id).setValue(order).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void unused) {
                    AlertDialog alertDialog  = new AlertDialog.Builder(getContext())
                            .setTitle("Order Messagee")
                            .setMessage("your order has been succfully placed " +
                                    "its under profile --> Myorders")
                            .setCancelable(false)
                            .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Database.getInstance(getContext()).getdao().deleteall();
                                }
                            }).create();
                    alertDialog.show();
                    firebaseDatabase.getReference().child("user").child(firebaseAuth.getUid()).child("orders").child(id).setValue(order);
                }
            });
        });
    }

    @Override
    public void onResume() {
        super.onResume();

        new Thread(){
            @Override
            public void run() {
                List<Entity> list = Database.getInstance(getContext()).getdao().getlist();
                if (list != null&&list.size()>0) {
                    for (int i=0;i<list.size();i++){
                        if (list.get(i).getQty()==0){
                            list.remove(i);
                        }
                    }
                    getActivity().runOnUiThread(() -> {
                        cart.setVisibility(View.VISIBLE);
                        imageView.setVisibility(View.GONE);
                        del.setVisibility(View.VISIBLE);
                        delcharge.setVisibility(View.VISIBLE);
                        total.setVisibility(View.VISIBLE);
                        totaltext.setVisibility(View.VISIBLE);
                        textView.setVisibility(View.GONE);
                        Log.d("runnning", "run: "+"cartvisible");
                        button.setVisibility(View.VISIBLE);
                        basketAdapter adapter = new basketAdapter(list, getContext());
                        cart.setAdapter(adapter);
                        cart.setLayoutManager(new LinearLayoutManager(getContext()));
                    });
                }
                else{
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            del.setVisibility(View.GONE);
                            delcharge.setVisibility(View.GONE);
                            total.setVisibility(View.GONE);
                            totaltext.setVisibility(View.GONE);
                            cart.setVisibility(View.GONE);
                            button.setVisibility(View.GONE);
                            imageView.setVisibility(View.VISIBLE);
                            textView.setVisibility(View.VISIBLE);
                        }
                    });

                }

            }

        }.start();

    }

    @Override
    public void onStop() {
        super.onStop();
        getContext().unregisterReceiver(broadcastReceiver);
    }
}