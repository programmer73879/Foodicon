package com.Foodicon.app.Fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.Foodicon.app.R;

import org.jetbrains.annotations.NotNull;


public class ProfileFragment extends Fragment {
TextView textView,myorder;
private  static ProfileFragment profileFragment;
public static synchronized ProfileFragment getInstance(){
    if (profileFragment==null){
        return profileFragment = new ProfileFragment();
    }
    return profileFragment;
}
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_profile, container, false);
    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        textView = view.findViewById(R.id.profile);
        myorder = view.findViewById(R.id.Myorders);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              getParentFragmentManager().beginTransaction().replace(R.id.container,new AccountFragment()).commit();
            }
        });
        myorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getParentFragmentManager().beginTransaction().replace(R.id.container,new Myorders()).commit();
            }
        });
    }
}