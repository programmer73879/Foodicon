package com.Foodicon.app.Activities;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class reciever  extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {

    }
}
