package com.Foodicon.app.Fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.Foodicon.app.Activities.Viewpager;
import com.Foodicon.app.Adapters.adapter;
import com.Foodicon.app.Adapters.cat_adapter;
import com.Foodicon.app.Adapters.slideradap;
import com.Foodicon.app.Database.Database;
import com.Foodicon.app.Database.Entity;
import com.Foodicon.app.Models.Cateogry;
import com.Foodicon.app.Models.Restaurant;
import com.Foodicon.app.Models.cats;
import com.Foodicon.app.Models.product;
import com.Foodicon.app.R;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.glide.slider.library.SliderLayout;
import com.glide.slider.library.animations.DescriptionAnimation;
import com.glide.slider.library.slidertypes.DefaultSliderView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;


public class HomeFragment extends Fragment {
    RecyclerView Restaurants;
    Toolbar toolbar;
    View view;
    TextView imageView;
    String city;
    RecyclerView banners, latitems;
    ArrayList<String> Banners, Sliders;
    ArrayList<product> Latestitems;
    ArrayList<Restaurant> arrayList;
    String id;
    private  static HomeFragment homeFragment=null;
    FirebaseDatabase firebaseDatabase;
    ArrayList<Cateogry> arrayList1;
    SliderLayout sliderLayout;
  public static synchronized HomeFragment getinstance(){
      if (homeFragment==null){
          homeFragment = new HomeFragment();
          return homeFragment;
      }
      return homeFragment;
  }
    @Override
    public void onCreate(@Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        arrayList = new ArrayList<>();
        Restaurants = null;
        Log.d("fragmenthome", "onCreate:  ");
        Banners = new ArrayList<>();
        Sliders = new ArrayList<>();
        Latestitems = new ArrayList<>();
        arrayList1 = new ArrayList<>();
        arrayList = new ArrayList<>();
        firebaseDatabase = FirebaseDatabase.getInstance();
        city = getContext().getSharedPreferences("User",Context.MODE_PRIVATE).getString("city",null);
        Log.d("tggg", "onCreate:  in hin"+city);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Log.d("tag", "onCreateView: "+city);
        if(view ==null){
            Log.d("tagsss", "onCreateView: "+"homecalled");
            view = inflater.inflate(R.layout.fragment_home, container, false);
        }
        return view;
    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Restaurants  = view.findViewById(R.id.cat_items);
        toolbar = view.findViewById(R.id.toolbar);
        sliderLayout = view.findViewById(R.id.slider);
        banners = view.findViewById(R.id.rcitems);
        imageView = view.findViewById(R.id.adres);
        latitems  = view.findViewById(R.id.product_items);

    }

    @Override
    public void onStart() {
        super.onStart();
//        toolbar.setLogo(R.drawable.icon_app);
//        toolbar.setTitle(" "+"Foodicon");
        Log.d("tag", "onStart: "+city);
        firebaseDatabase.getReference().child("Restaurants").orderByChild("city").equalTo(city).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                arrayList.clear();
                for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                    Log.d("tagss", "onDataChange: " + snapshot1.getKey() + "dets");
                    id = snapshot1.getKey();
                    Restaurant restaurant = snapshot1.getValue(Restaurant.class);
                    SharedPreferences.Editor editor = getContext().getSharedPreferences("Restaurant",Context.MODE_PRIVATE).edit();
                    editor.putString("resid",snapshot1.getKey());
                    editor.putString("Address",restaurant.getAddress());
                    editor.putFloat("lat", (float) restaurant.getLat());
                    Log.d("iop", "onDataChange: "+(float)restaurant.getLat());
                    Log.d("iop", "onDataChange: "+(float)restaurant.getLong());
                    editor.putFloat("long", (float) restaurant.getLong());
                    editor.putString("name",restaurant.getName());
                    editor.commit();
                    firebaseDatabase.getReference().child(snapshot1.getKey()).child("Category").addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                            if (arrayList1.size() > 0) {
                                arrayList1.clear();
                            }
                            for (DataSnapshot snapshot2 : snapshot.getChildren()) {
                                Cateogry cats = snapshot2.getValue(Cateogry.class);
                                cats.setId(snapshot2.getKey());
                                arrayList1.add(cats);
                                Log.d("mbn", "onDataChange: "+cats.getUrl());
                            }
                            cat_adapter adapter = new cat_adapter(arrayList1, getContext());
                            Restaurants.setLayoutManager(new LinearLayoutManager(getContext()));
                            Restaurants.setAdapter(adapter);
                        }

                        @Override
                        public void onCancelled(@NonNull @NotNull DatabaseError error) {

                        }
                    });
                            firebaseDatabase.getReference().child(id+"dets").child("Banners").addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                                    Banners.clear();

                                    for (DataSnapshot snapshot2:snapshot.getChildren()){
                                        Banners.add(snapshot2.getValue(String.class));
                                        Log.d("links", "onDataChangemmmmm: "+snapshot2.getValue(String.class));
                                    }
                                    slideradap a = new slideradap(Banners,getContext());
                                    banners.setAdapter(a);
                                }
                                @Override
                                public void onCancelled(@NonNull @NotNull DatabaseError error) {

                                }
                            });
                            firebaseDatabase.getReference().child(id+ "dets").child("Slider").addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                                    sliderLayout.removeAllSliders();
                                    RequestOptions requestOptions = new RequestOptions();
                                    requestOptions.centerCrop();
                                    Log.d("connc", "onDataChange: "+snapshot.getChildrenCount());
                                    for (DataSnapshot snapshot2:snapshot.getChildren()) {
                                         DefaultSliderView sliderView = new DefaultSliderView(getContext());
                                        // if you want show image only / w ithout description text use DefaultSliderView instead
                                        // initialize SliderLayout
                                        sliderView
                                                .image(snapshot2.getValue(String.class))
                                                .setRequestOption(requestOptions)
                                                .setProgressBarVisible(true);

                                        //add your extra information
                                        sliderLayout.addSlider(sliderView);
                                    }

                                    // set Slider Transition Animation
                                    // mDemoSlider.setPresetTransformer(SliderLayout.Transformer.Default);
                                    sliderLayout.setPresetTransformer(SliderLayout.Transformer.Accordion);
                                    sliderLayout.setPresetIndicator(SliderLayout.PresetIndicators.Center_Bottom);
                                    sliderLayout.setCustomAnimation(new DescriptionAnimation());
                                    sliderLayout.setDuration(2000);
                                    sliderLayout.stopCyclingWhenTouch(false);
                                }

                                @Override
                                public void onCancelled(@NonNull @NotNull DatabaseError error) {

                                }
                            });
                            firebaseDatabase.getReference().child(id + "dets").child("special").addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                                    Latestitems.clear();
                                    for (DataSnapshot snapshot2:snapshot.getChildren()) {
                                        product product = snapshot2.getValue(com.Foodicon.app.Models.product.class);
                                        product.setId(snapshot2.getKey());
                                        Latestitems.add(product);
                                    }
                                    adapter adapter = new adapter(Latestitems,getContext());
                                    latitems.setAdapter(adapter);
                                }
                                @Override
                                public void onCancelled(@NonNull @NotNull DatabaseError error) {

                                }
                            });
                        }
                }


            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });
    }
    @Override
    public void onResume() {
        super.onResume();
    }

}