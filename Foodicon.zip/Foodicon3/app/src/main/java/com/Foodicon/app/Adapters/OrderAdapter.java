package com.Foodicon.app.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.Foodicon.app.Activities.ordertrack;
import com.Foodicon.app.Database.Entity;
import com.Foodicon.app.Models.order;
import com.Foodicon.app.Models.product;
import com.Foodicon.app.R;
import com.google.firebase.auth.internal.RecaptchaActivity;

import java.util.ArrayList;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.holder> {
ArrayList<order> arrayList;
Context context;

    public OrderAdapter(ArrayList<order> arrayList, Context context) {
        this.arrayList = arrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
    View view = LayoutInflater.from(context).inflate(R.layout.orderstatuslayout,parent,false);
    return  new holder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull holder holder, int position) {
     holder.total.setText(String.valueOf(arrayList.get(position).getTotal()));
     holder.dattime.setText(arrayList.get(position).getOrderdate()+" at "+arrayList.get(position).getOrdertime());
     holder.itemsdet.setText("");
     for (Entity p:arrayList.get(position).getArrayList()){
         holder.itemsdet.append(String.valueOf(p.getQty()+" X "+p.getName()));
     }
     holder.itemView.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             Intent intent = new Intent();
             intent.putExtra("id",arrayList.get(position).getOrderid());
         context.startActivity(new Intent(context, ordertrack.class));
         }
     });
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class holder extends RecyclerView.ViewHolder {
        TextView resname,total,itemsdet,dattime ;
        ImageView resimage;
        public holder(@NonNull View itemView) {
            super(itemView);
            resname = itemView.findViewById(R.id.resname);
            resimage = itemView.findViewById(R.id.resimage);
            total = itemView.findViewById(R.id.total);
            itemsdet = itemView.findViewById(R.id.itemsdet);
            dattime = itemView.findViewById(R.id.dattime);

        }
    }
}
