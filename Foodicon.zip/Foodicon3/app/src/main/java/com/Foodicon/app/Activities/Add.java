package com.Foodicon.app.Activities;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.Foodicon.app.Database.Database;
import com.Foodicon.app.Database.Entity;
import com.Foodicon.app.R;
import com.mcdev.quantitizerlibrary.HorizontalQuantitizer;
import com.mcdev.quantitizerlibrary.QuantitizerListener;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class Add extends AppCompatActivity {
CircleImageView circleImageView;
TextView name,price,tagline;
HorizontalQuantitizer horizontalQuantitizer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.prodetail);
        circleImageView = findViewById(R.id.img);
        name = findViewById(R.id.name);
        price = findViewById(R.id.price);
        Entity entity = Database.getInstance(Add.this).getdao().getentity(getIntent().getStringExtra("id"));
        horizontalQuantitizer = findViewById(R.id.add);
        tagline = findViewById(R.id.text);
        if (entity==null){
            horizontalQuantitizer.setValue(0);
        }
        else {
            horizontalQuantitizer.setValue(entity.getQty());
        }
        Picasso.with(this).load(getIntent().getStringExtra("image")).into(circleImageView);
        name.setText(getIntent().getStringExtra("name"));
        price.setText("$" + String.valueOf(getIntent().getDoubleExtra("price", 0)));
        tagline.setText(getIntent().getStringExtra("tagline"));
        horizontalQuantitizer.setQuantitizerListener(new QuantitizerListener() {
            @Override
            public  void onIncrease() {
                int to = horizontalQuantitizer.getValue();
                if (to==0){
                    return;
                }
                SharedPreferences.Editor editor = getSharedPreferences("Cart",MODE_PRIVATE).edit();
                editor.putInt("total",++to);
                editor.apply();
                if (entity==null){
                    Entity entity1 = new Entity();
                    entity1.setId(getIntent().getStringExtra("id"));
                    entity1.setName(getIntent().getStringExtra("name"));
                    entity1.setQty(1);
//                    int total = context.getSharedPreferences("cart",Context.MODE_PRIVATE).getInt("total",0);
//                    total = (int) (total+arrayList1.getPrice());
//                    context.getSharedPreferences("cart",Context.MODE_PRIVATE).edit().putInt("total",total).commit();
                    entity1.setImage(getIntent().getStringExtra("image"));
                    entity1.setPrice(getIntent().getDoubleExtra("price",0));
                    entity1.setTag(getIntent().getStringExtra("tagline"));
                    entity1.setType(getIntent().getStringExtra("type"));
                    Database.getInstance(Add.this).getdao().insert(entity1);
                }
                else {
                    Entity entity1 = Database.getInstance(Add.this).getdao().getentity(getIntent().getStringExtra("id"));

                    int qty = entity1.getQty();
                    entity1.setQty(++qty);
//                    int total = context.getSharedPreferences("cart",Context.MODE_PRIVATE).getInt("total",0);
//                    total = (int) (total+entity.getPrice());
//                    context.getSharedPreferences("cart",Context.MODE_PRIVATE).edit().putInt("total",total).commit();
                    Database.getInstance(Add.this).getdao().update(entity1);
                }
            }

            @Override
            public void onDecrease() {
                int to = horizontalQuantitizer.getValue();
                if (to==0){
                    return;
                }
                SharedPreferences.Editor editor = getSharedPreferences("Cart",MODE_PRIVATE).edit();
                editor.putInt("total",--to);
                editor.apply();
                int q = horizontalQuantitizer.getValue();
                if (++q==0){
                    return;
                }
                if (entity!=null){
                    int qty = entity.getQty();
                    entity.setQty(--qty);
                    Database.getInstance(Add.this).getdao().update(entity);
                if (qty==0){
                    Database.getInstance(Add.this).getdao().delete(entity);
                }
                }
            }
        });
    }
}